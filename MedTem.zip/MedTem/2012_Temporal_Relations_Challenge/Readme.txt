*******This is a brief decsription of the i2b2 sample data*********
1. Data files:
   The group of 3 files with file extentions: txt, extent and tlink
are in the format that are consistent with the previous i2b2 challenges.
   In addition, an xml file is provided for each record. The XML 
file is browsable using the MAE tool found in the directory.

2. Usage of MAE tool
   - Download and unzip the MAE.zip 
   - Run the MAE_v0.9.3.jar (please make sure that you have Java installed)
   - In menu bar, select File -> Load DTD, and in the popup window,
     navigate to the sample folder in the unzipped MAE folder, load the
     TemporalAnnotation.dtd
   - Then, select File -> Load File, and load one of the records, e.g. 
     357.xml
   - You will be able to browse the annotations by clicking on different
     tabs.